import React, { useEffect, useRef, useState } from 'react';
import { View, StyleSheet, BackHandler, Linking, Alert } from 'react-native';
import { WebView } from 'react-native-webview';
import { useNavigation } from '@react-navigation/native';
import * as Location from "expo-location";

const AppContent = () => {
  const [isLoading, setIsLoading] = useState(true);

  const getLocation = async () => {
    try {
      await Location.requestBackgroundPermissionsAsync();
      const { coords: { latitude, longitude } } = await Location.getCurrentPositionAsync();
      console.log(latitude, longitude);
      setIsLoading(false);
      // 여기에서 위치 정보 사용 가능 (latitude, longitude)
    } catch (e) {
      Alert.alert("위치정보를 가져올 수 없습니다.");
    }
  };

  const navigation = useNavigation();
  const webviewRef = useRef(null);

  const backAction = () => {
    if (webviewRef.current) {
      // WebView에서 뒤로 가기 동작 처리
      webviewRef.current.goBack();
      return true; // 기본 동작 방지
    } else {
      return false; // 기본 동작 허용
    }
  };

  const backHandler = BackHandler.addEventListener('hardwareBackPress', backAction);

  useEffect(() => {
    getLocation()
    return () => backHandler.remove();
  }, [backHandler]);

  return (
    <View style={styles.container}>
      <WebView
        ref={webviewRef}
        source={{ uri: 'https://www.guphani.com/html/index.html' }}
        onShouldStartLoadWithRequest={(event) => {
          // 전화 및 문자 메시지 링크 처리
          if (event.url.startsWith('tel:') || event.url.startsWith('sms:')) {
            Linking.openURL(event.url);
            return false;
          }
          return true;
        }}
        onError={(syntheticEvent) => {
          const { nativeEvent } = syntheticEvent;
          console.warn('WebView error: ', nativeEvent);
        }}
        originWhitelist={['*']}
        style={styles.webView}
        javaScriptEnabled={true}
        bounces={false}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        mixedContentMode={'never'} // 보안 설정
        startInLoadingState={true}
        javaScriptEnabledAndroid={true}
        onMessage={(event) => {
          const message = event.nativeEvent.data;
          if (message.startsWith('tel:') || message.startsWith('sms:')) {
            Linking.openURL(message);
          }
        }}
        domStorageEnabled
        cacheEnabled
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  webView: {
    marginTop: 0,
    marginBottom: 0,
    marginLeft: 0,
    marginRight: 0,
    width: '100%',
    height: '100%',
    borderRadius: 8,
    borderWidth: 0,
    borderColor: 'white',
    backgroundColor: 'white',
    overflow: 'scroll',
  },
});

export default AppContent;
